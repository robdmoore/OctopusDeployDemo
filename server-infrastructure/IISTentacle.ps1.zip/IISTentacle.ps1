Configuration IISTentacle
{
    param ($ApiKey, $OctopusServerUrl, $Environments, $Roles, $ListenPort)

    Import-DscResource -Module .\OctopusDSC

    Node "localhost"
    {
        WindowsFeature IIS
        {
            Ensure = �Present�
            Name = �Web-Server�
        }

        WindowsFeature ASP
        {
            Ensure = �Present�
            Name = �Web-Asp-Net45�
        }

        WindowsFeature WebServerManagementConsole
        {
            Name = "Web-Mgmt-Console"
            Ensure = "Present"
        }

        cTentacleAgent OctopusTentacle 
        { 
            Ensure = "Present"; 
            State = "Started"; 

            Name = "Tentacle";

            ApiKey = $ApiKey;
            OctopusServerUrl = $OctopusServerUrl;
            Environments = $Environments;
            Roles = $Roles;

            ListenPort = $ListenPort;
            DefaultApplicationDirectory = "C:\Applications"
        }
    }
} 